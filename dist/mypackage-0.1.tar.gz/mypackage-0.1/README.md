# mypackage
This library was created as an example of how to publish a Python package.

## building package locally
`python setup.py sdist`

## installing this package from github
`pip install git+https://github.com/Thembisile/example-python-package.git`

## updating this package from github
`pip install --upgrade git+https://github.com/Thembisile/example-python-package.git`
